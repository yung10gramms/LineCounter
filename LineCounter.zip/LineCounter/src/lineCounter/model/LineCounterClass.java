package lineCounter.model;

import lineCounter.model.consoleInterface.ConsoleText;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Vector;

public class LineCounterClass {

    private String path;
    private CreateFile filecreator;

    private String outputPath;

    private ConsoleText consoleText;

    public LineCounterClass(String path, ConsoleText textPane, String outputPath) {
        filecreator = new CreateFile(outputPath);
        filecreator.fileCreate();
        this.path = path;
        consoleText = textPane;
        this.outputPath = outputPath;
    }

    public int countLinesInFile(String fileName, boolean countEmptyLinesToo)
    {

        int out = 0;
        try {
            File myObj = new File(fileName);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String s = myReader.nextLine();
                filecreator.fileWrite(s);
                //System.out.println(s);
                if(countEmptyLinesToo)
                    out++;
                else if( !s.equals(""))
                    out++;
            }
            myReader.close();
            return out;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        //probably dead code
        return -1;
    }

    public void listFiles(Vector<File> files)
    {
        for(int i = 0; i < files.size(); i ++)
        {
            System.out.println(files.get(i).getAbsolutePath());
        }
    }


    public Vector<File> getFiles()
    {
        Vector<File> files = new Vector<File>();
        getFilesHelp(path, files);
        return files;
    }

    public void getFilesHelp(String dir, Vector<File> files)
    {
        File[] flist = new File(dir).listFiles();
        for(int i = 0; i < flist.length; i ++)
        {
            if(! flist[i].isDirectory())
            {
                files.add(flist[i]);
            } else
            {
                getFilesHelp(flist[i].getAbsolutePath(), files);
            }
        }
    }

    private int getNum(boolean getEmpty)
    {
        Vector<File> files = getFiles();

        int numberOfFiles = enumerateFiles();
        int count = 0;

        for(int i = 0; i < files.size(); i ++)
        {
            consoleText.setText(consoleText.getText()+"Searching in file " +files.get(i).getAbsolutePath());
            count = count + countLinesInFile(files.get(i).getAbsolutePath(), getEmpty);
            consoleText.updateProgress(count, numberOfFiles, this);
        }

        filecreator.fileClose();

        return count;
    }

    public int getNumAll()
    {
        return getNum(true);
    }

    public int getNumNonEmpty()
    {
        return getNum(false);
    }

    public int enumerateFiles()
    {
        return getFiles().size();
    }



}
