package lineCounter.model.consoleInterface;

public interface Colored {
    public void updateTheme();

    public void updateTheme(Theme t);
}
