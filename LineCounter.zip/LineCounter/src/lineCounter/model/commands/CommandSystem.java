package lineCounter.model.commands;

import lineCounter.model.LineCounterClass;
import lineCounter.model.SystemHandler;
import lineCounter.model.consoleInterface.ConsoleFrame;
import lineCounter.model.consoleInterface.ConsoleText;
import lineCounter.model.serialize.StorageHandler;

import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.event.*;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.NumberFormat;
import java.util.Vector;

public class CommandSystem implements ActionListener, DocumentListener, KeyListener, WindowListener {
    private String currentPath;

    private Vector<Command_> system_commands;
    private Vector<String> commandsInserted;

    private int currentCommandIndex;

    private ConsoleText t;

    private static final String[] no_output_str = {""};
    private static final String[] command_not_found = {"\ncommand not found\n"};

    private static CommandSystem instance = new CommandSystem();


    public static CommandSystem getInstance()
    {
        return instance;
    }

    private CommandSystem()
    {
        currentPath = System.getProperty("user.dir");
        system_commands = CommandDatabase.getCommands();
        commandsInserted = StorageHandler.loadCommandHistory(currentPath);
    }

    public String getCurrentPath()
    {
        return currentPath;
    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        System.out.println(actionEvent.getActionCommand());

    }

    @Override
    public void insertUpdate(DocumentEvent documentEvent) {

    }

    @Override
    public void removeUpdate(DocumentEvent documentEvent) {

    }

    @Override
    public void changedUpdate(DocumentEvent documentEvent) {

    }



    @Override
    public void keyTyped(KeyEvent keyEvent) {


    }

    @Override
    public void keyPressed(KeyEvent keyEvent) {

        if(keyEvent.getKeyCode() == KeyEvent.VK_ENTER)
        {
            ConsoleText t = (ConsoleText) keyEvent.getSource();
            this.t = t;
            String com = t.getCommand();
            com = com.trim();
            System.out.println("<"+com+">");
            Command_ newCommand = searchCommand(com);
            if(com.contentEquals(""))
            {
                //do nth
            }
            else
            {
                if(newCommand == null)
                {
                    t.printCommandNotFound();
                }
                else
                {
                    handleCommand(newCommand, t);
                }
                commandsInserted.add(com);
            }
            currentCommandIndex = commandsInserted.size() - 1;
            t.startNextLine();
        }
        if(keyEvent.getKeyCode() == KeyEvent.VK_UP)
        {
            ConsoleText t = (ConsoleText) keyEvent.getSource();
            this.t = t;
            //t.setText();
            t.deleteCommand();
            if(currentCommandIndex > 0)
                currentCommandIndex--;
            if(currentCommandIndex >= 0 && commandsInserted.size() != 0)
                t.appendToPane(commandsInserted.get(currentCommandIndex), t.getForeground());
        }
        if(keyEvent.getKeyCode() == KeyEvent.VK_DOWN)
        {
            ConsoleText t = (ConsoleText) keyEvent.getSource();
            this.t = t;
            t.deleteCommand();
            if(currentCommandIndex < commandsInserted.size()-1) {
                currentCommandIndex++;
                t.appendToPane(commandsInserted.get(currentCommandIndex), t.getForeground());
            } else
            {
                t.appendToPane("", t.getForeground());
            }
        }

    }

    private void handleCommand(Command_ command, ConsoleText textPane)
    {
        if(command.getName().contentEquals("help"))
        {
            textPane.executeCommand(help());
        }
        if(command.getName().contains("linecounter"))
        {
            System.out.println(command.getName());
            textPane.executeCommand(lineCounter(command));
        }
        if(command.getName().contentEquals("ls"))
        {
            textPane.executeCommand(ls());
        }
        if(command.getName().contains("cd"))
        {
            textPane.executeCommand(cd(command));
            fixPath();
        }
        if(command.getName().contentEquals("exit") || command.getName().contentEquals("close") )
        {
            if(SystemHandler.getNumberOfWindows() > 1)
            {
                textPane.panel().parent().setVisible(false);
                return;
            }
            exitOperation();
        }
        if(command.getName().contentEquals("terminate") )
        {
            exitOperation();
        }
        if(command.getName().contentEquals("clear") || command.getName().contentEquals("clc"))
        {
            textPane.executeCommand(clear(textPane.panel().parent()));
            System.gc();
        }
        if(command.getName().contentEquals("cmd"))
        {
            textPane.executeCommand(cmd());
        }
        if(command.getName().contentEquals("ram"))
        {
            textPane.executeCommand(ram());
        }
        if(command.getName().contentEquals("win"))
        {
            textPane.executeCommand(win());
        }
        if(command.getName().contentEquals("man"))
        {
            textPane.executeCommand(man(searchCommand(command.getParams()[0])));
        }
        if(command.getName().contentEquals("gc"))
        {
            textPane.executeCommand(gc());
        }
    }

    public void exitOperation()
    {

        StorageHandler.storeCommandsString(currentPath, commandsInserted);
        exit();
    }

    private void fixPath()
    {
        currentPath.replace("//", "/");
    }

    public void print(String n)
    {
        System.out.println(n);
    }

    private Command_ searchCommand(String name)
    {
        String name_to_search = name.split(" ")[0];
        String[] command_in_strings = name.split(" ");
        for(int i = 0; i < system_commands.size(); i ++)
        {
            if(system_commands.get(i).getName().contentEquals(name_to_search))
            {
                String params_in_str = "";
                for(int k = 0; k < command_in_strings.length - 1; k ++)
                {
                    params_in_str = params_in_str + command_in_strings[k + 1];
                }
                system_commands.get(i).setParams(params_in_str);
                return system_commands.get(i);
            }
        }
        return null;
    }

    @Override
    public void keyReleased(KeyEvent keyEvent) {

    }

    public String[] help()
    {
        final int len = 80;
        String[] coms = new String[system_commands.size()];
        for (int i = 0; i < system_commands.size(); i ++)
        {
            coms[i] = system_commands.get(i).getName();
        }
        for(int i = 0; i < coms.length; i ++)
        {
            int comSize = coms[i].length();
            int descSize = system_commands.get(i).getDescription().length();
            int rest = len - comSize - descSize;
            String dots = "";
            for(int j = 0; j < rest; j ++)
            {
                dots = dots + ".";
            }
            coms[i] = coms[i] + dots + system_commands.get(i).getDescription();
        }
        return coms;
    }

    public String[] lineCounter(Command_ command)
    {
        String[] out = new String[2];
        if(command.getParams() == null || command.getParams().length == 0 || command.getParams()[0] == null || command.getParams()[0].contentEquals(""))
        {
             Path path = Paths.get(currentPath);
            if(Files.exists(path))
            {

                try
                {

                    LineCounterClass lin = new LineCounterClass(currentPath, t, currentPath);
                    out[0] = "line counter: ";
                    out[1] = "               " +lin.getNumAll();
                }
                catch (NullPointerException nex)
                {
                    out[0] = "line counter: ";
                    out[1] = "            command for counting lines in a certain directory. Please type it" +
                            "in the format 'linecounter <path/to/directory>'";
                }
            } else
            {
                out[0] = "line counter: ";
                out[1] = "            command for counting lines in a certain directory. Please type it" +
                        "in the format 'linecounter <path/to/directory>'";

            }
        }
        else
        {
            String path = command.getParams()[0];
            LineCounterClass lin = new LineCounterClass(path, t, currentPath);
            out[0] = "line counter: ";
            out[1] = "               " +lin.getNumAll();
        }
        return out;
    }

    public String[] ls()
    {
        File[] flist = new File(currentPath).listFiles();
        String[] names = new String[flist.length];
        for(int i = 0; i < flist.length; i ++)
        {
            names[i] = flist[i].getName();
        }
        return names;
    }

    public String[] cd(Command_ command)
    {
        String path_in_cd = command.getParams()[0];
        if(path_in_cd.charAt(0) == '/')
        {
            return cdHelp(command, path_in_cd);
        }
        else if(path_in_cd.charAt(0) == '.')
        {
            if(! path_in_cd.contentEquals(".."))
            {
                String[] out = {"false input"};
                return out;
            }
            else
            {
                String[] parentDir = currentPath.split("/");
                int lastIndex = 0;
                if(parentDir[parentDir.length - 1] == "/")
                {
                    lastIndex = parentDir.length - 2;
                }
                else
                {
                    lastIndex = parentDir.length - 1;
                }
                String[] builtStrArray = new String[lastIndex];
                path_in_cd = "";
                for(int i = 0; i < lastIndex; i ++)
                {
                    builtStrArray[i] =  parentDir[i];
                }
                for(int i = 0; i < lastIndex; i ++)
                {
                    path_in_cd = path_in_cd + "/" + builtStrArray[i];
                }
                path_in_cd = path_in_cd + "/";
                return cdHelp(command, path_in_cd);
            }
        }
        else //child dir
        {
            return cdHelp(command, currentPath + "/" +path_in_cd);
        }

    }

    private String[] cdHelp(Command_ command, String path_in_cd)
    {
        Path path = Paths.get(path_in_cd);
        if(Files.exists(path))
        {
            File file = new File(path_in_cd);
            if(file.isDirectory())
            {
                //cool
                currentPath = path_in_cd;
                return no_output_str;
            } else
            {
                String[] out_str = {"cannot use cd in regular files (non-dirs)"};
                return out_str;
            }
        }
        else
        {
            String[] out_str = {"cannot cd to non-existing directory"};
            return out_str;
        }
    }

    public String[] clear(ConsoleFrame frame)
    {
        frame.reset();
        return no_output_str;
    }

    public String[] exit()
    {
        System.exit(0);
        return no_output_str;
    }

    public String[] cmd()
    {

        String[] out = (String[]) commandsInserted.toArray(new String[commandsInserted.size()]);
        if(out == null || out.length == 0)
            return no_output_str;
        return out;
    }

    public String[] ram()
    {
        String[] out = new String[4];
        Runtime runtime = Runtime.getRuntime();


        long maxMemory = runtime.maxMemory();
        long allocatedMemory = runtime.totalMemory();
        long freeMemory = runtime.freeMemory();

        NumberFormat format = NumberFormat.getInstance();

        int denominator = 1024 * 1024;
        
        out[0] = "free memory: " + format.format(freeMemory / denominator) + "kBytes";
        out[1] = "allocated memory (for vm): " + format.format(allocatedMemory / denominator) + "kBytes";
        out[2] = "max memory: " + format.format(maxMemory / denominator) + "kBytes";
        out[3] = "total free memory: " +
                format.format((freeMemory + (maxMemory - allocatedMemory)) / denominator) + "kBytes";
        return out;
    }

    public String[] win()
    {
        SystemHandler.newWindow();
        return no_output_str;
    }

    public String[] gc()
    {
        System.gc();
        return no_output_str;
    }

    public String[] man(Command_ command)
    {
        if(command == null)
        {
            return command_not_found;
        }
        String[] out = {command.getManual()};
        return out;
    }

    @Override
    public void windowOpened(WindowEvent windowEvent) {

    }

    @Override
    public void windowClosing(WindowEvent windowEvent) {
        ConsoleFrame fr = (ConsoleFrame)  windowEvent.getSource();
        if(SystemHandler.getNumberOfWindows() > 1)
        {
            fr.setVisible(false);
            fr = null;
            return;
        }

        exitOperation();
    }

    @Override
    public void windowClosed(WindowEvent windowEvent) {

    }

    @Override
    public void windowIconified(WindowEvent windowEvent) {

    }

    @Override
    public void windowDeiconified(WindowEvent windowEvent) {

    }

    @Override
    public void windowActivated(WindowEvent windowEvent) {

    }

    @Override
    public void windowDeactivated(WindowEvent windowEvent) {

    }
}
