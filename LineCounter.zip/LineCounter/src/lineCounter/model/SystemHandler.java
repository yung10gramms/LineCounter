package lineCounter.model;

import lineCounter.model.commands.CommandSystem;
import lineCounter.model.consoleInterface.ConsoleFrame;

public class SystemHandler {

    private static int numberOfWindows = 0;

    public static void main(String[] args)
    {
        newWindow();
    }

    public static void newWindow()
    {
        new ConsoleFrame(CommandSystem.getInstance());
        numberOfWindows++;
    }

    public static int getNumberOfWindows()
    {
        return numberOfWindows;
    }
}
